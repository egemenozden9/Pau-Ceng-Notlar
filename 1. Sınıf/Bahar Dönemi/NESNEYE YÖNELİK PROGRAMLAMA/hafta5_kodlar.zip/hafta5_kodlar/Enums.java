/*
Enum türleri önceden tanımlanmış sabit değerleri ifade etmek için kullanılır.
Enum bildirimi bir Sınıfın dışında veya bir Sınıfın içinde yapılabilir, ancak bir metodun içinde yapılamaz.
Every enum is internally implemented by using Class.
Her enum sabiti, enum türünde bir nesneyi temsil eder.
enum türü, ifadeleri değiştirmek için bir argüman olarak iletilebilir.


values(), ordinal() ve valueOf() yöntemleri:

Bu yöntemler Java.lang.Enum içinde bulunur.
Enum içinde bulunan tüm değerleri döndürmek için value() yöntemi kullanılabilir.
enums'ta sıra önemlidir.
ordinal() yöntemini kullanarak, her bir enum sabit dizini, tıpkı bir dizi dizini gibi bulunabilir.
valueOf() yöntemi, varsa belirtilen dize değerinin enum sabitini döndürür.
 */
import java.util.Random;
import java.util.Arrays;

enum Color {
    RED,
    GREEN,
    BLUE;
}



public class Enums {

    private static final Random randomNumbers = new Random();


    /* internally above enum Color is converted to
class Color
{
     public static final Color RED = new Color();
     public static final Color BLUE = new Color();
     public static final Color GREEN = new Color();
//Her enum sabiti, enum türünde bir nesneyi temsil eder.
//enum türü, ifadeleri değiştirmek için bir argüman olarak iletilebilir.
}*/
    public enum Gun {
        PAZARTESI,
        SALI,
        CARSAMBA,
        PERSEMBE,
        CUMA,
        CUMARTESI,
        PAZAR
    }

    public static boolean haftasonuMu(Gun gun) {

        if(gun == Gun.CUMARTESI || gun == Gun.PAZAR) {
            return true;
        }
        return false;
    }
    public static void main(String[] args) {

        Color c1 = Color.RED;
        System.out.println(c1);

        // Calling values()
        Color arr[] = Color.values();
        System.out.println("array value:" + arr[0]);
        // enum with loop

        for (int i = 0; i < arr.length; i++) {
            System.out.printf("array value in index %d: %s%n", arr[i].ordinal(), arr[i]);

        }
/*
        for (Color col : arr) {
            // Calling ordinal() to find index
            // of color.
            System.out.println(col);
            System.out.println(col + " at index " + col.ordinal());
        }
*/

        /*
        Gun gun1 = Gun.PAZAR;
        Gun gun2 =Gun.CARSAMBA;
        boolean sor =Enums.haftasonuMu(gun1);

        if (sor) {
            System.out.println("hafta sonu");
        }else {
            System.out.println("hafta içi");
        }

        */


        /*
        //index tahmin ettir
        int gun = 1 + randomNumbers.nextInt( 7 );
        Gun arr1[] = Gun.values();
        System.out.println("seçilen gün:"+arr1[gun]);

        switch (arr1[gun]) {
            case PAZAR:
            case CUMARTESI:
                System.out.println("hafta sonu");
                break;
            case PAZARTESI:
            case SALI:
            case CARSAMBA:
            case PERSEMBE:
            case CUMA:
                System.out.println("hafta içi");
                break;
            default:
                System.out.println("uygun günü giriniz");
                break;
        }

        if (arr1[gun] == Gun.CUMARTESI || arr1[gun] == Gun.PAZAR) {
            System.out.println("Yatış :)");
        }

*/


    }


}
