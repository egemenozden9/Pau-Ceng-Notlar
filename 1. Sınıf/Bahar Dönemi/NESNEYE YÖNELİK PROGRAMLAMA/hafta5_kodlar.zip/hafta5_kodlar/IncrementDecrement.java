import sun.lwawt.macosx.CSystemTray;

public class IncrementDecrement {

    public static void main(String[] args) {
        int operand = 2;
        System.out.printf("Increment Operand:%d%n",operand--);
        System.out.printf("Increment Operand:%d%n",operand);

        System.out.printf("Increment Operand:%d%n",--operand);
        System.out.printf("Increment Operand:%d%n",operand);


        int operandB = 2;
        //++operand; // operand = 2
        int numberB = ++operandB; // operand = 2, number = 2
        System.out.printf("Number:%d - Operand:%d%n",numberB,operandB);

        int operandL = 1;
        operandL++; // operand = 2
        int numberL = operandL++; //

        System.out.printf("Increment later- Number:%d - Operand:%d%n",numberL,operandL);




    }
}
