public class Main {

    public static void main(String[] args) {
	// write your code here
       // int m=Math.max(23, Math.max(56,76));
       // System.out.println(m);

// String birleştirme + concenation
        int sayi1=5,sayi2=4;

        int toplam = sayi1 + sayi2;
        System.out.println(toplam);
        System.out.println(toplam+toplam);
        System.out.println("String deneme:"+toplam+toplam);

        //System.out.println("sayi1+3="+sayi1+3);
        //System.out.println("sayi1+3="+(sayi1+3));

       // boolean bl=true;
/*
        int i=5;
        int j=i;
        i=7;
        System.out.println(j);

        String s1 = new String("a");
        String s2 = new String("b");
        String tmp=s1;
        s1=s2;
        s2=tmp;
        System.out.println(s1);
        System.out.println(s2);
        System.out.println(tmp);

*/
        //çevrim-conversion-casting
        /*
        Java’da genişleten çevirimler otomatik olarak yapılır, çevirimin olması için
        atama yapmak dışında başka bir şeye gerek yoktur.
         */

        //boolean b=12;
        int uzun =20;
        double d1=uzun;  // genişleten çevrim
        long lg1=uzun;
        System.out.println(uzun);
        System.out.println(d1);
        System.out.println(lg1);

        /*
        Java’da daraltan çevirimler otomatik olarak yapılmaz, derleyici hata verir.
        Daraltan çevirim yapabilmek için çevirme işlemcisi (cast operator) olan "()" kullanılır:
            • Atama yapılırken, çevirilen tip, çevirme işlemcisi içine yazılır.
         */
        double d2=12.45;
        int i2= (int) d2; //daranltan çevrim-casting
        System.out.println(d2);
        System.out.println(i2);

    }


}

//https://ibrahimbilge.com/java-object-oriented-kavrami-i/#:~:text=Yaz%C4%B1l%C4%B1m%20object'lerinin%20%C3%B6zellikleri%20field,ler%20ile%20ili%C5%9Fki%20kurabilmesini%20sa%C4%9Flar.