//created by ikok-27.03.2022
public class StackDemo {
    public static void main(String[] args) {
        System.out.printf("1: Main çalıstı\n");
        f();
        u(8);
    }
     public static void f(){
         System.out.printf("2: F çalıstı\n");
         g(false);
         System.out.printf("4: g'den F'e dönüldü\n");
         g(true);
     }
    public static void g(boolean b){
        if(b==true){
            System.out.printf("5: g()-> b=true - u tetikle\n");
            u(6);
            System.out.printf("7: u() sonrası g-f kapanış- \n");
        }
        else {
            System.out.printf("3: g()-> b=False - f()'ye geri dön\n");}
    }
    public static void u(int deger){
        System.out.printf("%d: U(%d) çalıstı\n",deger,deger);}
}
